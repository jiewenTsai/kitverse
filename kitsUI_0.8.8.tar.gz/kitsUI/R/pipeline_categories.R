# 分數類別的問題：沒有人得 0 分、分數不連續、只有一種分數
#   不改分數；只列出來。② 校準時：題庫裡的題固定在題庫的值，不在題庫的題這一回合不放進來

#' 每個資料量尺（領域 × 世代）裡分數類別有問題的題
#'
#' 只看給的這些列（例如這一回合勾選的波次）。一題可以有好幾個問題，放在同一列。
#' @param df 長格式資料（domain、cohort、item_id、item_score）
#' @return tibble：scale（資料的量尺）、item_id、problem（英文："no 0 score"、"score gap"、
#'   "one score only"，好幾個時以 ", " 分開）、detail_zh（一句中文，例如
#'   「lanc01 沒有人得 0 分（分數 1、2、3）」）、detail_en（英文，寫進固定檔的 checks.csv；
#'   不含題號，例如 "no score 0 (scores 1, 2, 3)"）。沒有問題時 0 列
#' @noRd
kitsui_category_problems <- function(df) {
  df |>
    dplyr::filter(!is.na(.data$item_score)) |>
    dplyr::summarise(scores = list(sort(unique(.data$item_score))),
                     .by = c("domain", "cohort", "item_id")) |>
    dplyr::mutate(scale = scale_key(.data$domain, .data$cohort)) |>
    dplyr::arrange(match(.data$scale, kitsui_scales(df)$scale), .data$item_id) |>
    dplyr::select("scale", "item_id", "scores") |>
    kitsui_problem_rows()
}

#' 作答矩陣每一欄（題）的分數類別問題
#' @param X 作答矩陣（每一列是一個列次 visit_id，每一欄是一題）
#' @param scale 寫進結果的量尺
#' @return 和 kitsui_category_problems() 一樣的 tibble
#' @noRd
kitsui_matrix_problems <- function(X, scale) {
  scores <- purrr::map(colnames(X), \(it) sort(unique(stats::na.omit(X[, it]))))
  tibble::tibble(scale = scale, item_id = colnames(X), scores = scores) |>
    dplyr::filter(lengths(.data$scores) > 0) |>
    kitsui_problem_rows()
}

# 每題一列（scale、item_id、scores 是排好的分數）-> 只留有問題的題，
#   加上 problem、detail_zh、detail_en
kitsui_problem_rows <- function(tab) {
  found <- purrr::map2(tab$item_id, tab$scores, kitsui_score_problem)
  tab |>
    dplyr::mutate(problem = purrr::map_chr(found, "problem"),
                  detail_zh = purrr::map_chr(found, "detail"),
                  detail_en = purrr::map_chr(found, "detail_en")) |>
    dplyr::filter(!is.na(.data$problem)) |>
    dplyr::select("scale", "item_id", "problem", "detail_zh", "detail_en")
}

#' 一題的分數有沒有問題
#' @param scores 這一題出現過的分數（排好、不重複）
#' @return list(problem, detail, detail_en)：沒有問題時都是 NA；detail_en 是英文、不含題號
#' @noRd
kitsui_score_problem <- function(item_id, scores) {
  # 原文：（分數  | 、 | ）
  seen <- paste0("\uff08\u5206\u6578 ", paste(scores, collapse = "\u3001"), "\uff09")
  if (length(scores) == 1) {
    return(list(problem = "one score only",
                # 原文：%s 每個人都得 %s 分，只有一種分數
                detail = sprintf("%s \u6bcf\u500b\u4eba\u90fd\u5f97 %s \u5206\uff0c\u53ea\u6709\u4e00\u7a2e\u5206\u6578", item_id, scores),
                detail_en = sprintf("one score only: everyone has %s", scores)))
  }
  missing <- setdiff(seq(min(scores), max(scores)), scores)
  no_zero <- min(scores) > 0
  problem <- c(if (no_zero) "no 0 score", if (length(missing) > 0) "score gap")
  if (length(problem) == 0) {
    return(list(problem = NA_character_, detail = NA_character_, detail_en = NA_character_))
  }
  # 原文：分數不連續，沒有人得 %s 分 | 、 | –
  gap <- sprintf("\u5206\u6578\u4e0d\u9023\u7e8c\uff0c\u6c92\u6709\u4eba\u5f97 %s \u5206", kitsui_runs(missing, "\u3001", "\u2013"))
  # 原文：沒有人得 0 分
  what <- c(if (no_zero) "\u6c92\u6709\u4eba\u5f97 0 \u5206", if (length(missing) > 0) gap)
  # 英文：例如 "no score 0; score gap: no score 2 (scores 1, 3)"
  gap_en <- paste("score gap: no score", kitsui_runs(missing, ", ", "-"))
  what_en <- c(if (no_zero) "no score 0", if (length(missing) > 0) gap_en)
  list(problem = paste(problem, collapse = ", "),
       # 原文：；
       detail = paste0(item_id, " ", paste(what, collapse = "\uff1b"), seen),
       detail_en = paste0(paste(what_en, collapse = "; "), " (scores ",
                          paste(scores, collapse = ", "), ")"))
}

#' 分數寫成連續的段：c(1, 2, 3, 5, 7, 8) -> "1–3、5、7–8"（遺漏碼 98 會讓中間少了 90 幾個分數，
#' 寫成一段才不會列出 90 個數字）
#' @param sep 段之間的符號；dash 是一段裡的符號
#' @noRd
# 原文：、 | –
kitsui_runs <- function(x, sep = "\u3001", dash = "\u2013") {
  x <- sort(unique(x))
  if (length(x) == 0) return("")
  start <- x[c(TRUE, diff(x) != 1)]
  end <- x[c(diff(x) != 1, TRUE)]
  ends <- dplyr::case_when(end == start ~ "", end == start + 1 ~ paste0(sep, end),
                           .default = paste0(dash, end))
  paste0(start, ends, collapse = sep)
}
