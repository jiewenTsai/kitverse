# 組裝整個 app：雲端版（根目錄 app.R）、本機 run.bat、套件 run_kitsui() 共用

#' 建立 kitsUI Shiny app 物件
#'
#' 三種啟動方式都呼叫這個函式，所以看到的畫面一致；
#' 雲端版會在上方與頁尾多顯示雲端使用須知。
#'
#' @return [shiny::shinyApp()] 物件
#' @export
kit_app <- function() {
  kit_set_options()
  shiny::shinyApp(ui = kit_ui, server = kit_server)
}

# 下載的 log 與 ASCII 備用檔名用的 app 名稱（kitDesign::kit_download_button()）
.onLoad <- function(libname, pkgname) {
  if (is.null(getOption("kitDesign.app"))) options(kitDesign.app = "kitsUI")
}

#' 啟動前的 Shiny 設定（上傳上限）；找 pandoc（圖檔下載要用）
#' @noRd
kit_set_options <- function() {
  options(
    shiny.maxRequestSize = KIT_UPLOAD_MB * 1024^2,
    shiny.autoload.r = FALSE
  )
  kit_setup_pandoc()
  kit_setup_manual()
}

#' 頁面（每次連線時產生，雲端判斷才會反映目前環境）
#' @noRd
kit_ui <- function(request) {
  # 主題、樣式、頁首：kitDesign；版本行是 kitsUI 的版本、日期與 kits 的版本
  ver <- kitDesign::kit_app_description("kitsUI")
  kitDesign::kit_page(
    # 原文：KIT 量尺建構工具 | 臺灣幼兒發展調查資料庫
    "KIT \u91cf\u5c3a\u5efa\u69cb\u5de5\u5177", "\u81fa\u7063\u5e7c\u5152\u767c\u5c55\u8abf\u67e5\u8cc7\u6599\u5eab",
    # 原文：量尺：校準、連結、計分
    tagline = "\u91cf\u5c3a\uff1a\u6821\u6e96\u3001\u9023\u7d50\u3001\u8a08\u5206",
    version = ver$version, date = ver$date, package = "kitsUI", validation = TRUE,
    meta_extra = paste0("kits v", utils::packageVersion("kits")),
    shiny::tags$head(shiny::tags$style(KITSUI_CSS)),
    if (kitDesign::kit_is_cloud()) kitsui_cloud_banner(),
    if (!kit_pandoc_ok()) kit_pandoc_notice(),
    # 「使用手冊」不是流程的一步：放最右邊、虛線框
    kitDesign::kit_flow_tabs(
      id = "tabs", aside = "manual",
      # 原文：① 資料
      shiny::tabPanel("\u2460 \u8cc7\u6599", value = "data", mod_data_ui("data")),
      # 原文：② 題目校準
      shiny::tabPanel("\u2461 \u984c\u76ee\u6821\u6e96", value = "items", mod_items_ui("items")),
      # 原文：③ 連結
      shiny::tabPanel("\u2462 \u9023\u7d50", value = "link", mod_link_ui("link")),
      # 原文：④ 受試者評分
      shiny::tabPanel("\u2463 \u53d7\u8a66\u8005\u8a55\u5206", value = "score", mod_score_ui("score")),
      # 原文：使用手冊
      shiny::tabPanel("\u4f7f\u7528\u624b\u518a", value = "manual", kit_manual_ui())
    ),
    if (kitDesign::kit_is_cloud()) kitsui_cloud_footer()
  )
}

# kitsUI 自己的幾條樣式（其他都在 kitDesign）：本機版到 kitJoin 的一行說明裡的程式碼
KITSUI_CSS <- ".kit-kitjoin-local code { font-size: 0.85rem; }"

#' 伺服器邏輯：各分頁模組之間只透過 reactive 傳資料
#' @noRd
kit_server <- function(input, output, session) {
  goto <- function(tab) {
    shiny::updateTabsetPanel(session, "tabs", selected = tab)
  }
  # ④ 交給 ① 的固定檔（這次連線接著做下一回合）；n 讓同一個固定檔再交一次也算數
  handover <- shiny::reactiveVal(NULL)
  next_round <- function(fixed, round) {
    n <- (shiny::isolate(handover())$n %||% 0) + 1
    handover(list(fixed = fixed, round = round, n = n))
    goto("data")
  }
  data <- mod_data_server("data", goto, handover)
  items <- mod_items_server("items", data, goto)
  links <- mod_link_server("link", data, items, goto)
  score <- mod_score_server("score", data, items, links, goto, next_round)
  # 有這一回合的結果時，離開頁面前先問一次
  shiny::observe(kitDesign::kit_unload_guard(!is.null(items()), session))
  # 步驟分頁的進度：做完的打 ✓，還不能做的灰色（kit_tabs.R）
  tab_states <- shiny::reactive({
    ok <- \(f) tryCatch(f(), error = \(e) NULL)
    lk <- ok(links)
    kitsui_tab_states(!is.null(ok(data)), ok(items), !is.null(lk) && length(lk$todo) == 0,
                      ok(score))
  })
  kitDesign::kit_watch_tab_states(session, shiny::reactive(kitsui_tab_send(tab_states())))
}
