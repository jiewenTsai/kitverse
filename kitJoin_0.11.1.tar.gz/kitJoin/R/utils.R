# 共用小工具

# 給使用者看的錯誤是 kitDesign::kit_abort(..., class = , data = )：白話中文、說明原因與怎麼修，
# 狀態框原文顯示（kit_error_status()）；其他未預期的錯誤包成「沒有預期到的問題」。

#' x 為 NULL 時改用 y（R 4.4 起 base 也有，這裡為了支援較舊的 R）
#' @noRd
`%||%` <- function(x, y) if (is.null(x)) y else x

#' 轉成文字，數字不用科學記號：100000 → "100000"（as.character() 會變成 "1e+05"）
#'
#' 各元素分開排版，1 和 1.5 會是 "1"、"1.5"；NA 保持 NA。
#' @noRd
num_to_text <- function(x) {
  if (!is.numeric(x)) return(as.character(x))
  v <- as.vector(unclass(x))
  out <- trimws(formatC(v, format = "fg", digits = 15))
  out[is.na(v)] <- NA_character_
  out
}

#' 每列的 ID 合成一個比對用字串；任一 ID 欄缺漏的列回傳 NA
#' @noRd
key_strings <- function(df, by_vars) {
  keys <- lapply(df[by_vars], function(x) num_to_text(unclass(x)))
  out <- do.call(paste, c(keys, sep = "\r"))
  has_na <- Reduce(`|`, lapply(keys, is.na))
  out[has_na] <- NA_character_
  out
}

#' 「t1（wave1.csv）」這種給使用者看的檔案稱呼
#' @noRd
file_display_name <- function(wave_label, file_name) {
  # 原文：（ | ）
  ifelse(nzchar(wave_label), paste0(wave_label, "\uff08", file_name, "\uff09"), file_name)
}
