# Install missing packages and update packages that are too old
#
# install.packages() installs only missing packages; it does not update one that is installed
# but too old (for example bslib 0.10 has no Brite theme, and kitsUI breaks as soon as it
# opens). This finds what is missing or too old with kitverse_requirements() and installs it
# in a separate R: on Windows a loaded package cannot be overwritten, and the other R has
# nothing loaded.

#' Install missing packages and update packages that are too old
#'
#' Finds the packages kitverse needs that are not installed or older than required
#' ([kitverse_requirements()]) and installs them from [kitverse_repos()]. A newly installed
#' package may need further packages, so this repeats until nothing is missing (at most
#' `rounds` times). The installation runs in a separate R process, so it does not matter what
#' the current R session has loaded.
#'
#' A freshly installed R has no personal package library yet; this creates it first
#' (`R_LIBS_USER`).
#'
#' @param all `TRUE` to also update packages that have a newer version in the repositories
#'   (not only those that are too old).
#' @param rounds At most how many rounds.
#' @param quiet `TRUE` to hide the installation output.
#' @return The packages installed or updated (invisibly).
#' @examples
#' if (interactive()) kitverse_update()
#' @export
kitverse_update <- function(all = FALSE, rounds = 4, quiet = FALSE) {
  lib <- ktv_user_library()
  repos <- kitverse_repos()
  release <- kitverse_release()
  done <- character(0)
  for (i in seq_len(rounds)) {
    req <- kitverse_requirements()
    todo <- req$pkg[!req$ok]
    if (all && i == 1) {
      # Packages with a newer version in the repositories (kitverse itself too), and KIT packages
      # older than the KIT release on GitHub
      old <- tryCatch(rownames(utils::old.packages(repos = repos)), error = function(e) NULL)
      todo <- union(todo, intersect(old, c(req$pkg, "kitverse")))
      todo <- union(todo, ktv_behind_release(release))
    }
    todo <- setdiff(todo, done)
    if (length(todo) == 0) break
    ktv_say("Installing or updating ", length(todo), " package", if (length(todo) > 1) "s",
            ": ", paste(todo, collapse = ", "))
    ktv_say("(the first time can take a few minutes; please keep R open)")
    # KIT packages that r-universe does not have yet in the release's version: from GitHub
    from_github <- ktv_bundle_needed(release, repos, intersect(todo, KTV_KIT_PKGS))
    if (length(from_github) > 0) {
      ktv_say("r-universe is behind; installing from the KIT release on GitHub: ",
              paste(from_github, collapse = ", "))
      ktv_bundle_install(from_github, release, lib = lib, cran = repos[["CRAN"]], quiet = quiet)
    }
    rest <- setdiff(todo, from_github)
    if (length(rest) > 0) ktv_install(rest, lib = lib, repos = repos, quiet = quiet)
    done <- c(done, todo)
  }
  req <- kitverse_requirements()
  if (all(req$ok)) {
    ktv_say("\u2714 All packages are installed.")
    # Saving plots as html needs pandoc; a computer with only R has none
    kitverse_pandoc()
    ktv_say("Next: kitverse::kitverse_check()")
  } else {
    bad <- req[!req$ok, , drop = FALSE]
    ktv_say("\u2716 Some packages still cannot be used: ", paste(bad$pkg, bad$why, collapse = "; "))
    ktv_say("  Check the internet connection and run kitverse::kitverse_update() again.")
  }
  invisible(done)
}

#' The personal package library: create it if needed and put it first on the library path
#' @noRd
ktv_user_library <- function() {
  lib <- Sys.getenv("R_LIBS_USER")
  if (!nzchar(lib)) return(.libPaths()[1])
  lib <- path.expand(strsplit(lib, .Platform$path.sep, fixed = TRUE)[[1]][1])
  dir.create(lib, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(lib) || file.access(lib, 2) != 0) return(.libPaths()[1])
  .libPaths(c(lib, .libPaths()))
  lib
}

#' Run install.packages() in a separate R
#' @noRd
ktv_install <- function(pkgs, lib, repos, quiet = FALSE) {
  script <- tempfile("kitverse-install-", fileext = ".R")
  on.exit(unlink(script), add = TRUE)
  writeLines(c(
    # Posit Package Manager picks the binary for this R version from the user agent
    'options(HTTPUserAgent = sprintf("R/%s R (%s)", getRversion(), paste(getRversion(), R.version[["platform"]], R.version[["arch"]], R.version[["os"]])))',
    sprintf("options(repos = %s)", ktv_deparse(repos)),
    sprintf(".libPaths(c(%s, .libPaths()))", ktv_deparse(lib)),
    sprintf("install.packages(%s, lib = %s, quiet = %s)",
            ktv_deparse(pkgs), ktv_deparse(lib), if (quiet) "TRUE" else "FALSE")
  ), script)
  status <- system2(ktv_rscript(), shQuote(script))
  if (!identical(status, 0L)) ktv_say("(the installer reported an error; checking again below)")
  invisible(status)
}

#' A value as R code (for the script the other R runs)
#' @noRd
ktv_deparse <- function(x) paste(deparse(x, width.cutoff = 500L), collapse = " ")

#' CRAN's current and previous R release, e.g. c(release = "4.6.2", oldrel = "4.5.3")
#'
#' r-universe and CRAN build Windows and macOS packages for these two (and R-devel); an older R gets
#' no new pre-built packages, so updating it would need Rtools to compile. NULL when CRAN cannot
#' be reached.
#' @noRd
ktv_r_releases <- function(url = "https://cloud.r-project.org/src/base/VERSION-INFO.dcf") {
  old <- options(timeout = 15)
  on.exit(options(old), add = TRUE)
  d <- tryCatch({
    con <- url(url)
    on.exit(close(con), add = TRUE)
    read.dcf(con, fields = c("Release", "Old-release"))
  }, error = function(e) NULL, warning = function(w) NULL)
  if (is.null(d) || anyNA(d[1, ])) return(NULL)
  c(release = unname(d[1, "Release"]), oldrel = unname(d[1, "Old-release"]))
}

#' Whether an R version still gets pre-built packages: its x.y is at least the old release's x.y
#' @noRd
ktv_r_supported <- function(rv, oldrel) {
  xy <- function(v) package_version(sub("^([0-9]+\\.[0-9]+).*$", "\\1", as.character(v)))
  xy(rv) >= xy(oldrel)
}

#' This R's Rscript
#' @noRd
ktv_rscript <- function() {
  exe <- if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript"
  file.path(R.home("bin"), exe)
}

#' Print one line (message(), so suppressMessages() can hide it)
#' @noRd
ktv_say <- function(...) message(paste0(...))

#' KIT packages installed in a version older than the KIT release (or not installed)
#' @noRd
ktv_behind_release <- function(release, lib.loc = NULL) {
  if (is.null(release)) return(character(0))
  behind <- vapply(seq_len(nrow(release)), function(i) {
    have <- ktv_installed_version(release$pkg[i], lib.loc)
    is.na(have) || utils::compareVersion(have, release$version[i]) < 0
  }, logical(1))
  release$pkg[behind]
}
